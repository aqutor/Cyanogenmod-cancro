#!/sbin/sh
#~~PROPERTY OF ZEROINFINITY @ XDA-DEVELOPERS
#~~DO NOT STEAL OR COPY!


if [ -z "`grep "China Telecom" /system/build.prop`" ]
then
echo "" >> /system/build.prop
echo "# China Telecom Patch" >> /system/build.prop
echo "persist.sys.timezone=Asia/Shanghai" >> /system/build.prop
echo "gsm.network.type=EvDo-rev.A" >> /system/build.prop
echo "ro.telephony.default_network=4" >> /system/build.prop
echo "ril.subscription.types=NV,RUIM" >> /system/build.prop
echo "ro.cdma.factory=china" >> /system/build.prop
echo "ro.cdma.home.operator.numeric=46003" >> /system/build.prop
echo "ro.cdma.home.operator.alpha=ChinaTelecom" >> /system/build.prop
echo "ro.ril.oem.nosim.ecclist=911,112,120,122,110,119" >> /system/build.prop

sed -i '/wifi.supplicant_scan_interval/s/15/150/g' /system/build.prop
sed -i '/persist.sys.display_prefer/s/3/0/g' /system/build.prop
sed -i '/persist.sys.display_ce/s/11/0/g' /system/build.prop
else
exit 0
fi